from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node


def generate_launch_description():
    dry = LaunchConfiguration('dry_run')
    return LaunchDescription([
        DeclareLaunchArgument('dry_run', default_value='true', choices=['true', 'false']),
        DeclareLaunchArgument('status_url', default_value='http://127.0.0.1:8098/api/people/follow-state'),
        Node(package='luka_person_following', executable='selected_bridge', output='screen',
             parameters=[{'status_url': LaunchConfiguration('status_url')}]),
        Node(package='tros_person_following', executable='tros_person_following',
             namespace='luka_person_following/official', output='screen',
             parameters=[{'detect_result_topic_name': '/luka/selected_seg_targets',
                          'image_width': 640.0, 'global_frame': 'map', 'robot_frame': 'base_footprint',
                          'target_filter_range_x_max': 4.0,
                          'target_filter_range_y_min': -3.0, 'target_filter_range_y_max': 3.0,
                          'follow_distance_min': 1.8, 'follow_distance_max': 2.0,
                          'cmd_vel_topic': PythonExpression(["'/luka_follow_dryrun/cmd_vel' if '", dry, "' == 'true' else '/cmd_vel'"])}],
             remappings=[('navigate_to_pose', PythonExpression(["'/luka_follow_dryrun/navigate_to_pose' if '", dry, "' == 'true' else '/navigate_to_pose'"])),
                         ('/buzzer_pattern', '/luka_follow_dryrun/buzzer_pattern'),
                         ('enable_blind_zone_observing', '/luka_follow_dryrun/enable_blind_zone_observing')]),
    ])
